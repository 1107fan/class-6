﻿namespace paint
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.畫筆色彩ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.藍ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.黑ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.紅ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.線條ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.細ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.中ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.粗ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.線條檬式ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.直線ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.短虛線ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.長短虛線ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.長虛線ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.備存梅案ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.畫筆色彩ToolStripMenuItem,
            this.線條ToolStripMenuItem,
            this.線條檬式ToolStripMenuItem,
            this.備存梅案ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(793, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 畫筆色彩ToolStripMenuItem
            // 
            this.畫筆色彩ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.藍ToolStripMenuItem,
            this.黑ToolStripMenuItem,
            this.紅ToolStripMenuItem});
            this.畫筆色彩ToolStripMenuItem.Name = "畫筆色彩ToolStripMenuItem";
            this.畫筆色彩ToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.畫筆色彩ToolStripMenuItem.Text = "畫筆色彩";
            // 
            // 藍ToolStripMenuItem
            // 
            this.藍ToolStripMenuItem.Name = "藍ToolStripMenuItem";
            this.藍ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.藍ToolStripMenuItem.Text = "藍";
            this.藍ToolStripMenuItem.Click += new System.EventHandler(this.藍ToolStripMenuItem_Click);
            // 
            // 黑ToolStripMenuItem
            // 
            this.黑ToolStripMenuItem.Name = "黑ToolStripMenuItem";
            this.黑ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.黑ToolStripMenuItem.Text = "黑";
            this.黑ToolStripMenuItem.Click += new System.EventHandler(this.黑ToolStripMenuItem_Click);
            // 
            // 紅ToolStripMenuItem
            // 
            this.紅ToolStripMenuItem.Name = "紅ToolStripMenuItem";
            this.紅ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.紅ToolStripMenuItem.Text = "紅";
            this.紅ToolStripMenuItem.Click += new System.EventHandler(this.紅ToolStripMenuItem_Click);
            // 
            // 線條ToolStripMenuItem
            // 
            this.線條ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.細ToolStripMenuItem,
            this.中ToolStripMenuItem,
            this.粗ToolStripMenuItem});
            this.線條ToolStripMenuItem.Name = "線條ToolStripMenuItem";
            this.線條ToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.線條ToolStripMenuItem.Text = "線條粗細";
            this.線條ToolStripMenuItem.Click += new System.EventHandler(this.線條ToolStripMenuItem_Click);
            // 
            // 細ToolStripMenuItem
            // 
            this.細ToolStripMenuItem.Name = "細ToolStripMenuItem";
            this.細ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.細ToolStripMenuItem.Text = "細";
            this.細ToolStripMenuItem.Click += new System.EventHandler(this.細ToolStripMenuItem_Click);
            // 
            // 中ToolStripMenuItem
            // 
            this.中ToolStripMenuItem.Name = "中ToolStripMenuItem";
            this.中ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.中ToolStripMenuItem.Text = "中";
            this.中ToolStripMenuItem.Click += new System.EventHandler(this.中ToolStripMenuItem_Click);
            // 
            // 粗ToolStripMenuItem
            // 
            this.粗ToolStripMenuItem.Name = "粗ToolStripMenuItem";
            this.粗ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.粗ToolStripMenuItem.Text = "粗";
            this.粗ToolStripMenuItem.Click += new System.EventHandler(this.粗ToolStripMenuItem_Click);
            // 
            // 線條檬式ToolStripMenuItem
            // 
            this.線條檬式ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.直線ToolStripMenuItem,
            this.短虛線ToolStripMenuItem,
            this.長短虛線ToolStripMenuItem,
            this.長虛線ToolStripMenuItem});
            this.線條檬式ToolStripMenuItem.Name = "線條檬式ToolStripMenuItem";
            this.線條檬式ToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.線條檬式ToolStripMenuItem.Text = "線條檬式";
            // 
            // 直線ToolStripMenuItem
            // 
            this.直線ToolStripMenuItem.Name = "直線ToolStripMenuItem";
            this.直線ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.直線ToolStripMenuItem.Text = "直線";
            this.直線ToolStripMenuItem.Click += new System.EventHandler(this.直線ToolStripMenuItem_Click);
            // 
            // 短虛線ToolStripMenuItem
            // 
            this.短虛線ToolStripMenuItem.Name = "短虛線ToolStripMenuItem";
            this.短虛線ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.短虛線ToolStripMenuItem.Text = "短虛線";
            this.短虛線ToolStripMenuItem.Click += new System.EventHandler(this.短虛線ToolStripMenuItem_Click);
            // 
            // 長短虛線ToolStripMenuItem
            // 
            this.長短虛線ToolStripMenuItem.Name = "長短虛線ToolStripMenuItem";
            this.長短虛線ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.長短虛線ToolStripMenuItem.Text = "長短虛線";
            this.長短虛線ToolStripMenuItem.Click += new System.EventHandler(this.長短虛線ToolStripMenuItem_Click);
            // 
            // 長虛線ToolStripMenuItem
            // 
            this.長虛線ToolStripMenuItem.Name = "長虛線ToolStripMenuItem";
            this.長虛線ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.長虛線ToolStripMenuItem.Text = "長虛線";
            this.長虛線ToolStripMenuItem.Click += new System.EventHandler(this.長虛線ToolStripMenuItem_Click);
            // 
            // 備存梅案ToolStripMenuItem
            // 
            this.備存梅案ToolStripMenuItem.Name = "備存梅案ToolStripMenuItem";
            this.備存梅案ToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.備存梅案ToolStripMenuItem.Text = "儲存檔案";
            this.備存梅案ToolStripMenuItem.Click += new System.EventHandler(this.儲存檔案ToolStripMenuItem_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button1.Location = new System.Drawing.Point(704, 387);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(84, 42);
            this.button1.TabIndex = 1;
            this.button1.Text = "清除";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(23, 47);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(623, 362);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDown);
            this.pictureBox1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseMove);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(793, 450);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "小畫家";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 畫筆色彩ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 藍ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 黑ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 紅ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 線條ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 細ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 中ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 粗ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 線條檬式ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 直線ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 短虛線ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 長短虛線ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 備存梅案ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 長虛線ToolStripMenuItem;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

